#pragma once

// bin2c converter ver0.1 by Moonlight.

#define snd_click_short_c_bin_Count (386)
#define snd_click_short_c_bin_Size (386)
extern const signed char snd_click_short_c_bin[386];

