#pragma once

// bin2c converter ver0.1 by Moonlight.

#define snd_click_long_c_bin_Count (2756)
#define snd_click_long_c_bin_Size (2756)
extern const signed char snd_click_long_c_bin[2756];

