#pragma once

// Console output to NDSRAM.
// OverlayDLL get from NDSRAM.
// Shutdown power request from NDSRAM.
#define InternalDebugMode

