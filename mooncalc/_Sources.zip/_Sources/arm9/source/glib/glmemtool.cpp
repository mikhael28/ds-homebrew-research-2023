
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <NDS.h>

#include "glib.h"
#include "glmemtool.h"

