#pragma once

#include <stdlib.h>
#include <NDS.h>

typedef u16 TglUnicode;

