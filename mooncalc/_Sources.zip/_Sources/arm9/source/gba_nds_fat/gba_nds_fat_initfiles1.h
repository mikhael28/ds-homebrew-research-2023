#pragma once

lfnNameUnicode[i] = 0;
