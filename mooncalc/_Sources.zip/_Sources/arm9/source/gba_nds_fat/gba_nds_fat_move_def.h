#pragma once

extern bool FAT_Move(const char *pSrcPath,const char *pDstPath);

