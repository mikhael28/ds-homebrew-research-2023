#pragma once

extern bool FAT_DeleteFile(const char *pSrcPath);

