#pragma once


#define DIMT_NONE (0x454e4f4e)

extern u32 DIMediaType;
extern const char *DIMediaName;
extern char DIMediaID[5];

