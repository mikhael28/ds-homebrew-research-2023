#pragma once

          lfnNameUnicode[0] = 0;
