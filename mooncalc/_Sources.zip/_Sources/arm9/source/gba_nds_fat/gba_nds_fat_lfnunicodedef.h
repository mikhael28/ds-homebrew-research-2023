#pragma once

__attribute__ ((section (".dtcm"))) UnicodeChar lfnNameUnicode[MAX_FILENAME_LENGTH];
