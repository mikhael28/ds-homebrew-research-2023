#pragma once

// bin2c converter ver0.1 by Moonlight.

#define chrglyph_999_Count (1520)
#define chrglyph_999_Size (1520)
extern const unsigned char chrglyph_999[1520];

