#pragma once

// bin2c converter ver0.1 by Moonlight.

#define versionerror_b8zlib_Count (4544)
#define versionerror_b8zlib_Size (4544)
extern const unsigned char versionerror_b8zlib[4544];

