#pragma once

// bin2c converter ver0.1 by Moonlight.

#define bootreply_b8zlib_Count (3692)
#define bootreply_b8zlib_Size (3692)
extern const unsigned char bootreply_b8zlib[3692];

