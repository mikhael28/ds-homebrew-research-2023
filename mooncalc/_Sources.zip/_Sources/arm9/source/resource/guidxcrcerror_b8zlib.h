#pragma once

// bin2c converter ver0.1 by Moonlight.

#define guidxcrcerror_b8zlib_Count (4188)
#define guidxcrcerror_b8zlib_Size (4188)
extern const unsigned char guidxcrcerror_b8zlib[4188];

