#pragma once

// bin2c converter ver0.1 by Moonlight.

#define bootwarn_b8zlib_Count (4256)
#define bootwarn_b8zlib_Size (4256)
extern const unsigned char bootwarn_b8zlib[4256];

