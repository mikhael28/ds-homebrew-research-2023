#pragma once

// bin2c converter ver0.1 by Moonlight.

#define _console_font_fixed6x6_packed_bin_Count (512)
#define _console_font_fixed6x6_packed_bin_Size (2048)
extern const unsigned int _console_font_fixed6x6_packed_bin[512];

