#pragma once

extern void PrfStart(void);
extern void PrfEnd(int data);
extern u32 PrfEnd_GetCPUCount(void);
extern u32 PrfEnd_Getus(void);

