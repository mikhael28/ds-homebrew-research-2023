#pragma once


#include <NDS.h>

extern void PlugWAVE_GetInternal(Tlibsnd_Internal *plibsnd_Internal);

