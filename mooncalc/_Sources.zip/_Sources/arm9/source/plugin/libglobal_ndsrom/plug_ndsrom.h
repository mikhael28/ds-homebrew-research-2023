#pragma once

#define NDSROMTitle "NDSROM bootloader ver0.5"

__declspec(noreturn) extern void BootNDSROM(const char *pFilename);
