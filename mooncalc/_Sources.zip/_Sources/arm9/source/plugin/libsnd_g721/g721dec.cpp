
#include <NDS.h>

#include "_console.h"
#include "_const.h"
#include "memtool.h"

#define abs(v) (v<0 ? -v : v)

#define INLINE inline

#include "g721dec.h"

#include "g721dec_ins_g72x.h"
#include "g721dec_ins_g721.h"

