#pragma once


#include <NDS.h>

extern void PlugG721_GetInternal(Tlibsnd_Internal *plibsnd_Internal);

